package com.cg.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.beans.Feedback;
import com.cg.capstore.beans.Response;
import com.cg.capstore.service.IFeedbackCommonService;

@RestController
public class FeedbackCommons_Controller {
	
	
	@Autowired
	IFeedbackCommonService fservice;
	
	@RequestMapping(value="/generateFeedbackToMerchantRequest")
	public void generateFeedbackRequest(@RequestBody Feedback feedback,HttpServletRequest request) {
	
		fservice.generateRequest(feedback);
		
	}
	
	@RequestMapping(value="/viewAllFeedbackRequests")
	public List<Feedback> viewAllFeedbackRequests(@PathVariable String AdminId,HttpServletRequest request){
		
		return fservice.viewAllFeedbackRequests();
		
	}
	
	@RequestMapping(value="/viewMyFeedbacks/{merchantId}")
	public List<Feedback> viewMyFeedbacks(@PathVariable int merchantId,HttpServletRequest request){
		
		//String mr_id= (String) request.getAttribute("ID");		
		
		return fservice.viewMyFeedbacks(merchantId);
		
	}
	
	
	@RequestMapping(value="/sendReply")
	public void sendReply(@RequestBody Response response,HttpServletRequest request) {
		
		fservice.sendResponseToAdmin(response);
		
	}
	
	@RequestMapping(value="/viewAllMerchantResponses")
	public List<Response> viwAllResponses(){
		
		return fservice.viewAllResponses();
		
	}

	@RequestMapping(value="/sendResponse/{responseId}")
	public String sendResponseToCustomer(@PathVariable String responseId,HttpServletRequest request) {
		
		fservice.sendResponseToCustomer(responseId);
		return "Response sent back to customer";
		
	}
	
	
	@RequestMapping(value="/viewResponses/{cust_id}")
	public List<Response> customerViewResponses(@PathVariable int cust_id,HttpServletRequest request){
		
		//String cust_id=(String)request.getAttribute("Id");
		
		return fservice.showMyResponse(cust_id);
		
	} 
	
}
