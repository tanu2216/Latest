package com.cg.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity

public class Response {

	@Id
	@Column(name="Feedback_ID")
	private String Feedback_Id;

	@Column(name="Customer_Id")
	private Customer customer;
	
	@Column(name="Merchant_Id")
	private Merchant merchant;
	
	@Column(name="Feedback_Comment")
	private String feedbackComment;
	
	@Column(name="Status")
	private String status;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public String getFeedbackComment() {
		return feedbackComment;
	}

	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
		
	
}
