package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.beans.Response;

public interface ResponseRepo extends JpaRepository<Response, String>{

	public List<Response> findByStatusAndCustomer(String status,int customerId);
	
}
