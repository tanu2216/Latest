package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.beans.Feedback;

public interface FeedbackRepo extends JpaRepository<Feedback, String>{

	public List<Feedback> findByStatus(String status);
	
	public List<Feedback> findByMerchant(int merchantId);

}
