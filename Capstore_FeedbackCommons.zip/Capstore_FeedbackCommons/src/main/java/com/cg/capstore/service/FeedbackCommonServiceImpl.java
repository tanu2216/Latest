package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.beans.Feedback;
import com.cg.capstore.beans.Response;
import com.cg.capstore.dao.FeedbackRepo;
import com.cg.capstore.dao.ResponseRepo;


@Service
public class FeedbackCommonServiceImpl implements IFeedbackCommonService {

	@Autowired
	FeedbackRepo frepo;
	
	@Autowired
	ResponseRepo responseRepo;
	
	@Override
	public void generateRequest(Feedback feedback) {
		
		frepo.save(feedback);
		
	}

	@Override
	public List<Feedback> viewAllFeedbackRequests() {
		
		return frepo.findByStatus("Requested");
		
	}

	@Override
	public List<Feedback> viewMyFeedbacks(int merchantId) {
		
		return frepo.findByMerchant(merchantId);
		
	}

	@Override
	public void sendResponseToAdmin(Response response) {
		
		responseRepo.save(response);
		
	}

	@Override
	public List<Response> viewAllResponses() {
		
		return responseRepo.findAll();
		
	}

	@Override
	public void	sendResponseToCustomer(String responseId) {
		
		responseRepo.findById(responseId).get().setStatus("Responded");
		frepo.findById(responseId).get().setStatus("Responded");
		
	}

	@Override
	public List<Response> showMyResponse(int cust_id) {
		
		return responseRepo.findByStatusAndCustomer("Responded",cust_id);
	
	}
	
	
	

}
