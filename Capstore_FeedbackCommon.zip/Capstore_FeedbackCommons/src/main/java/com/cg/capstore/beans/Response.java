package com.cg.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Response {

	@Id
	@Column(name="Response_ID")
	private String Response_Id;

	@Column(name="Customer_Id")
	private int customerId;
	
	@Column(name="Merchant_Id")
	private int merchantId;

	
	@Column(name="Feedback_Comment")
	private String feedbackComment;
	
	@Column(name="Response")
	private String response;
	
	@Column(name="Status")
	private String status;


	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getFeedbackComment() {
		return feedbackComment;
	}

	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponse_Id() {
		return Response_Id;
	}

	public void setResponse_Id(String response_Id) {
		Response_Id = response_Id;
	}
		
}
