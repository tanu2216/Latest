package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.beans.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Integer> {

}
